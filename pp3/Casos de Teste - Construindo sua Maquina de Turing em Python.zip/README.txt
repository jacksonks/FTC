Arquivo zip gerado em: 16/11/2016 19:10:04 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Construindo sua Máquina de Turing em Python